def lambda_handler(event, context):
    print("lambda triggered")
    print(event)
    print(context)
    # todo trigger step function


    return event
